#!/bin/bash

read -p "Enter source IP(IP of server): " src
read -p "Enter destination IP(IP of client): " dst
read -p "Enter position that server will extract message from: " posi

sudo python3 /server/server_receiver.py -s "$src" -d "$dst" -p "$posi"
