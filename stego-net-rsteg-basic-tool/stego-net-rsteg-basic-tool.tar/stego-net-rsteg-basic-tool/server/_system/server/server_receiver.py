from scapy.all import *
from time import time
import argparse

SERVER_IP = None
CLIENT_IP = None
STEG_MESS_POSI = None

WAITING_TIME = 0

FIRST_STEP_HAND_SHAKE = False
CONNECT_STATUS = False

STEG_STATUS = False
STEG_MESS = []
LOST_PACKETS = {}
EXPECT_CLIENT_SEQ = 0
RSTEG = False

def hand_shake(packet):

    global FIRST_STEP_HAND_SHAKE
    global CONNECT_STATUS
    global WAITING_TIME
    global EXPECT_CLIENT_SEQ

    if(time() - WAITING_TIME < 2):

        return
    
    if(CONNECT_STATUS):
        packet_handler(packet=packet)

        return

    elif(FIRST_STEP_HAND_SHAKE):
        if(packet.haslayer(TCP) == False):
            print("You must use TCP to do this lab")
            print("-" * 50)

            return
            
        ip_layer = packet[IP]
        tcp_layer = packet[TCP]

        print_packet_infor(ip_layer=ip_layer, tcp_layer=tcp_layer, summary=packet.summary())
            
        if(tcp_layer.flags != 'A'):
            FIRST_STEP_HAND_SHAKE = False

            print("Hand-shake process failed because your packet's flag is not correct\
                  ")
            print("-" * 50)
        
        elif(tcp_layer.seq != EXPECT_CLIENT_SEQ):
            FIRST_STEP_HAND_SHAKE = False

            print("Hand-shake process failed because your packet's seq is not correct")
            print("-" * 50)
            
            return
        
        elif(tcp_layer.flags == 'A'):
            CONNECT_STATUS = True

            print("Hand-shake process success")
            print("-" * 50)
            
    else:
        print("Taking Hand-shake process...")

        if packet.haslayer(IP) and packet[IP].src == CLIENT_IP:
            ip_layer = packet[IP]

            if(packet.haslayer(TCP) == False):
                print("You must use TCP to do this lab")
                print("-" * 50)

                return
            
            tcp_layer = packet[TCP]

            print_packet_infor(ip_layer=ip_layer, tcp_layer=tcp_layer, summary=packet.summary())

            FIRST_STEP_HAND_SHAKE = (tcp_layer.flags == 'S' and tcp_layer.ack == 0)

            if(FIRST_STEP_HAND_SHAKE):
                send_syn_ack_packet(client_packet=packet)

                print("First step hand-shake success")
                print("-" * 50)
                EXPECT_CLIENT_SEQ = tcp_layer.seq + 1

def packet_handler(packet):

    global WAITING_TIME
    global STEG_STATUS
    global STEG_MESS
    global EXPECT_CLIENT_SEQ
    global LOST_PACKETS
    global RSTEG
    if(time() - WAITING_TIME < 2 ):
        return

    if packet.haslayer(IP) and packet[IP].src == CLIENT_IP:
        if packet.haslayer(TCP) == False:
            print("You must use TCP to do this lab")

            print("-" * 50)
            return

        ip_layer = packet[IP]
        tcp_layer = packet[TCP]
        
        print_packet_infor(ip_layer=ip_layer, tcp_layer=tcp_layer, summary=packet.summary())

        if packet.haslayer(Raw):
            print(f"Payload: {packet[Raw].load} {len(packet[Raw].load)}")
            # for i in range(len(packet[Raw].load)):
            #     print(f"Ky tu thu {i}: {packet[Raw].load[i]}")
            print("-" * 50)

        if(tcp_layer.flags == ('F' or 'FA' or 'SA')):
            stop_connection()

            return
            
        # sua lai doan nay la phat hien rsteg xong goi tin sau do se la goi tin phat hien
        # chu khong de la gui goi tin phat lai lien tuc
        # goi signaling thi phai cau hinh payload luon vi 
        # id se co xu huong tang len (do IP or hdh )
        # them 1 check word de goi la so sanh goi tin phat lai, neu nhu co dap unwg du dieu kien 
        #tuc la trong co ve giong voi goi tin phat lai nhat thi them 1 checkwork
        if(STEG_STATUS):
            STEG_STATUS = False
            if(cmp_lost_n_retrans_packet(retrans_packet=packet)):
                print("Hurray, you seems understand retransmission packet")
            
            else:
                print("Your retransmission packet is not correct, please try again UwU")
            RSTEG = True
            send_packet(client_packet=packet)
            extracted_steg_mess = extract_steg_mess(payload=packet[Raw].load, steg_len=int(packet[TCP].seq))
            print("Extracted Message: {steg_mess}".format(steg_mess=extracted_steg_mess))
            print("-" * 50)
        
        else:
            if(ip_layer.flags == 2):
                STEG_STATUS  = True
                try:
                    LOST_PACKETS[packet.seq] = packet
                except Exception:
                    print(f"Loi voi LOST_PACKETS {Exception}")
                print("Found RSTEG Signal...") 
                print("-" * 50)

                return

        send_packet(client_packet=packet)

def print_packet_infor(ip_layer, tcp_layer, summary):
    print(f"Nhận gói tin từ: {ip_layer.src} đến -> {ip_layer.dst}")
    print(f"Thông tin của gói tin: {summary}")

    print(f"TCP - Seq: {tcp_layer.seq}, Ack: {tcp_layer.ack}, Flags: {tcp_layer.flags}")
    print("-" * 50)

def send_syn_ack_packet(client_packet):
    global EXPECT_CLIENT_SEQ
    global WAITING_TIME

    if client_packet.haslayer(Raw):
        server_ack = client_packet[TCP].seq + len(client_packet[Raw].load)
    else:
        server_ack = client_packet[TCP].seq

    server_ip_packet = IP(src=SERVER_IP, dst=CLIENT_IP)
    server_tcp_packet = TCP(flags='SA', seq = 1, ack = server_ack)
    server_syn_ack_packer = server_ip_packet / server_tcp_packet

    send(server_syn_ack_packer, verbose=0)
    WAITING_TIME = time()

    print("Sent back a syn_ack packet for client")
    print("-" * 50)

def send_packet(client_packet):
    global WAITING_TIME

    server_ack = client_packet[TCP].seq + \
        (len(client_packet[Raw].load) if client_packet.haslayer(Raw) else 0)

    server_ip_packet = IP(src=SERVER_IP, dst=CLIENT_IP)
    server_tcp_packet = TCP(flags="A", seq=2, ack=server_ack)
    server_packet = server_ip_packet / server_tcp_packet

    send(server_packet, verbose=0) 
    WAITING_TIME = time() 

def extract_steg_mess(payload, steg_len: int):
    global STEG_MESS
    print(STEG_MESS_POSI)

    if(len(payload) <= STEG_MESS_POSI ):
        print(f"Your packet's payload is not correct, payload's length must be > {STEG_MESS_POSI}, Please try again!!!")
        print("-" * 50)

        return
    try:
        extracted_bytes = payload[STEG_MESS_POSI - 1:STEG_MESS_POSI + steg_len]
        extracted_steg_mess = ''.join([chr(b) for b in extracted_bytes])
        return extracted_steg_mess
    
    except Exception:
        print(Exception)

def stop_connection():

    global FIRST_STEP_HAND_SHAKE
    global CONNECT_STATUS
    global RSTEG

    if RSTEG:
        print("Your connection is canceled, sêe ju later.... <._.>")
    else:
        print("Your connection is canceled, sêe ju later... <._.>")
    FIRST_STEP_HAND_SHAKE = False
    CONNECT_STATUS = False
    RSTEG = False
    
    print("-" * 50)

def cmp_lost_n_retrans_packet(retrans_packet):
    global LOST_PACKETS
    if(retrans_packet.haslayer(Raw) == False):
        return False
    
    try:
        lost_packet = LOST_PACKETS[retrans_packet.seq]

        if (lost_packet.dport == retrans_packet.dport and 
            lost_packet.sport == retrans_packet.sport and 
            lost_packet.src == retrans_packet.src and 
            lost_packet.dst == retrans_packet.dst and 
            lost_packet.proto == retrans_packet.proto):

            if lost_packet.id != retrans_packet.id:
                return False
        else:
            if lost_packet.id == retrans_packet.id:
                return False

        if len(lost_packet[Raw].load) != len(retrans_packet[Raw].load):
            return False

    except Exception as Err:  # Sửa 'Err' thành 'Exception as Err'
        print(Err)
        return False
    
    return True

parser = argparse.ArgumentParser(description="Trình bắt gói tin")
parser.add_argument('-s', '--src', dest='source', required=True, help='IP nguồn (server)')
parser.add_argument('-d', '--dst', dest='destination', required=True, help='IP đích (client)')
parser.add_argument('-p', '--posi', dest='position', required=True, type=int, help=\
                    'Define the position that server extract steg mess from')

if __name__ == "__main__":
    args = parser.parse_args()
    CLIENT_IP = args.destination
    SERVER_IP = args.source
    STEG_MESS_POSI = args.position

    print("Started to listen packet from client...")
    sniff(filter=f"ip and src host {CLIENT_IP} and not tcp-ack", prn=hand_shake, store=0)
