from scapy.all import *
import argparse
import random
from time import sleep

SERVER_IP = None
CLIENT_IP = None

def hand_shake_handler():
    print("Process hand-shake...")
    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
    client_tcp = TCP(sport=random.randint(1024,65535), flags='S', seq=1)

    client_packet = client_ip / client_tcp
    send(client_packet, verbose=0)

    sleep(2)
    client_packet.seq += 1
    client_packet[TCP].flags = 'A'
    send(client_packet, verbose=0)
    print("Done!!!")

def rsteg_signal_handler():
    print("Processing rsteg_signal packet...")
    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP, flags=2)
    client_tcp = TCP(sport=random.randint(1024, 65535), seq=1)

    client_packet = client_ip / client_tcp
    send(client_packet, verbose=0)
    print("Done!!!")

def steg_mess_handler(posi:str, steg_mess:str):
    print("Processing steg_mess packet...")
    posi = int(posi)
    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP, flags=2)
    client_tcp = TCP(sport=random.randint(1024, 65535), seq=len(steg_mess))
    payload = Raw(load=gener_payload(posi, steg_mess))

    client_packet = client_ip / client_tcp / payload
    send(client_packet, verbose=0)
    print("Done!!!")

def gener_payload(pos: int, mess:str):
    payload = []
    cnt = 0
    for _ in range(pos * 2 + 1):
        cnt+=1
        if(cnt == 3):
            cnt = 0
            payload.append(chr(random.randint(27, 133)))
        
        else:
            
            payload.append('\x00')
    
    for i in range(len(mess)):
        payload.insert(pos + i, mess[i])

    return "".join(payload)

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='RSTEG tool' )
    parser.add_argument('-s', '--src', dest='source', required=True, help='source IP (client)') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='destination IP (server)') # corrected help message

    parser.add_argument('-ha', '--hand_shake', dest='hand_shake', action='store_true', help="Operate hand-shake process")
    parser.add_argument('-rs', '--rsteg_signal', dest='rsteg_signal', action='store_true', help='Send Rsteg_signal packet')
    parser.add_argument('-st', '--steg_mess', dest='steg_mess', help='Send Steg_mess packet')
    parser.add_argument('-p', '--posi', dest='position', help='The position to hide steg_mess')
    # parser.add_argument('-se', '--seq', dest='sequence', help='Defind current sequence')

    args = parser.parse_args()
    CLIENT_IP = args.source
    SERVER_IP = args.destination

    if((args.hand_shake and args.rsteg_signal) or(args.hand_shake and args.steg_mess) or \
       (args.rsteg_signal and args.steg_mess) or (args.hand_shake and args.steg_mess and \
                                                  args.rsteg_signal)):
        print("You should chose only one option hand-shake or rsteg-signal or steg-mess!")

    elif(args.hand_shake):
        hand_shake_handler()
    
    elif(args.rsteg_signal):
        rsteg_signal_handler()
    
    elif(args.steg_mess):
        if(args.position):
            steg_mess_handler(args.position, args.steg_mess)
        
        else:  
            print("You are missing position param for this option!")
    
    

    
