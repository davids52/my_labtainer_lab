#!/bin/bash

read -p "Result: " result

sudo python3 /client/check_result.py -r "$result"
