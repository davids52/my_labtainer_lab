import argparse

def check_result(result:str):
    if(result == "I LoVE PtIT"):
        print("Task 1 Done!")
    
    elif(result == "I Love Ptit"):
        print("Task 2 Done!")
    
    elif(result == "Hachke1or"):
        print("Task 3 Done1")
    
    else: 
        print("Your result is not correct, Please check each word carefully")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-r', '--resu', dest='result', required=True, help='Student\'s result')

    args = parser.parse_args()
    check_result(args.result)
    
