from scapy.all import *
import random
import argparse
import time
import hashlib
TARGET = "0.0.0.0"
ATTACKER_IP = "0.0.0.0"

CAUGHT_PAKCETS = {}
def packet_handler(packet: object):
    global CAUGHT_PAKCETS
    
    
    if(TARGET == packet[IP].src):
        try:
            if CAUGHT_PAKCETS[packet.seq]:
                if(check_normal_rsteg_packet(current_packet=packet, retrans_packet=CAUGHT_PAKCETS[packet.seq])):
                    print("Found packet with Seq={seq} that may be a rsteg_signal packet, Extracted\
                          Payload: {payload}".format(payload=packet_payload_handler(packet, True), seq=packet.seq))
                
                elif(check_encrypt_rsteg_packet(current_packet=packet, retrans_packet=CAUGHT_PAKCETS[packet.seq])):
                    print("Found packet with Seq={seq} that may be a rsteg_signal packet, Extracted\
                          Payload: {payload}".format(payload=packet_payload_handler(packet, False), seq=packet.seq))
                
        except Exception:
            CAUGHT_PAKCETS[packet.seq] = packet

def check_normal_rsteg_packet(current_packet: object, retrans_packet: object):
    return True if(current_packet.flags != retrans_packet.flags) else False 
    
def check_encrypt_rsteg_packet(current_packet: object, retrans_packet: object):
    detected = False

    tcp_bytes = retrans_packet[TCP].build().hex()
    old_tcp_chksum = calculate_old_tcp_chksum(tcp_bytes=tcp_bytes, ip_src=ATTACKER_IP, ip_dst=TARGET)
    rsteg_signal = calcu_IS(retrans_packet.seq, old_tcp_chksum, 0, "sha256")
    rsteg_signal_bytes = rsteg_signal.encode()
    # print(f"Goi rsteg {retrans_packet.seq} co IS duoc tinh lai ={rsteg_signal}")

    for i in range(0, len(retrans_packet.load) - 64):
        if(retrans_packet.load[0 + i:64+i] == rsteg_signal_bytes):
            print("Detect rsteg_signal packet using sha256")
            detected = True
            return detected

    rsteg_signal = calcu_IS(retrans_packet.seq, old_tcp_chksum, 0, "md5")
    rsteg_signal_bytes = rsteg_signal.encode()
    for i in range(0, len(retrans_packet.load) - 32):
        if(retrans_packet.load[0 + i:32 + i].encode() == rsteg_signal_bytes):
            print("Detect rsteg_signal packet using md5")
            detected = True
            return detected
#     md5	32	16	
# sha1	40	20	
# sha224	56	28	
# sha256	64	32	
# sha384	96	48	
# sha512	128	64	
# sha3_224	56	28	SHA3 Family
# sha3_256	64	32	
# sha3_384	96	48	
# sha3_512	128	64	
# blake2s	64	32	BLAKE2 (tối ưu cho 32-bit)
# blake2b	128	64	BLAKE2 (tối ưu cho 64-bit)
# shake_128	Variable	Any length	Extendable-output (XOF)
# shake_256	Variable	Any length	

    return detected

def packet_payload_handler(current_packet: object, is_encrypted: bool):
    extracted_payload = ''
    if current_packet.haslayer(Raw):
        payload = current_packet[Raw].load
        if is_encrypted:
            # Xử lý mã hóa
            filtered = [chr(byte) for byte in payload if 33 <= byte <= 125]
        else:
            # Không mã hóa
            filtered = [chr(byte) for byte in payload if 33 <= byte <= 125]
        extracted_payload = ' '.join(filtered)
    return extracted_payload
        

def calculate_old_tcp_chksum(tcp_bytes, ip_src, ip_dst):
    # Tách TCP header và payload
    tcp = bytes.fromhex(tcp_bytes)
    tcp_header = tcp[:20]
    payload = None

    # Trích xuất các trường TCP
    sport = int.from_bytes(tcp_header[0:2], 'big')
    dport = int.from_bytes(tcp_header[2:4], 'big')
    seq = int.from_bytes(tcp_header[4:8], 'big')
    ack = int.from_bytes(tcp_header[8:12], 'big')
    data_offset_reserved_flags = int.from_bytes(tcp_header[12:14], 'big')
    window = int.from_bytes(tcp_header[14:16], 'big')
    checksum_received = int.from_bytes(tcp_header[16:18], 'big')
    urg_ptr = int.from_bytes(tcp_header[18:20], 'big')

    data_offset = (data_offset_reserved_flags >> 12)
    flags = (data_offset_reserved_flags & 0x3f)

    ip = IP(src=ip_src, dst=ip_dst, proto=6) 
    tcp = TCP(
        sport=sport,
        dport=dport,
        seq=seq,
        ack=ack,
        dataofs=data_offset,
        flags=flags,
        window=window,
        urgptr=urg_ptr,
        chksum=None  # Đặt checksum = 0 để Scapy tính lại
    )

    packet = ip / tcp / Raw(load=None)
    # print("Tinh toan lai packet cua seq: {seq} ---> {hehe}".format(seq=packet.seq, hehe=packet[TCP].build().hex()))
    old_tcp_checksum = packet[TCP].build().hex()[32:36]
    return old_tcp_checksum

def calcu_IS(seq: str, chksum: str, sign_bit, encrypt_type: str):
    unhashed_str = str(seq) + chksum + str(sign_bit)
    unhashed_str = unhashed_str.encode('utf-8')
    # print("Unhash_Str:", unhashed_str)
    if(encrypt_type == "sha256"):
        hashed_str = hashlib.sha256(unhashed_str)
    
    elif(encrypt_type == "md5"):
        hashed_str = hashlib.md5(unhashed_str)


    hashed_hex = hashed_str.hexdigest()

    return hashed_hex

if __name__ == "__main__":
    print("Scanning, Please wait......///")
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-s', '--src', dest='source', required=True, help='IP of attacker') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='IP of victim') # corrected help message

    args = parser.parse_args()
    TARGET = args.destination
    ATTACKER_IP = args.source

    print("Ready to receive packet From Client...")
    sniff(filter=f"ip and src host {TARGET} and not tcp-ack", prn=packet_handler, store=0)
