#!/bin/bash

read -p "Enter target IP(IP of client): " target
read -p "Enter your IP(IP of attacker): " attacker

sudo python3 /attacker/attacker.py -s "$attacker" -d "$target"
