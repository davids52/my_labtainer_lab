import argparse
import random

def gener_payload(pos: int):
    payload = ''

    for _ in range((pos // 3) + 1):
        payload += f'\\x00\\x00{chr(random.randint(50,100))}'
    
    return payload
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Trinh tao payload')
    parser.add_argument('-p', '--pos', dest='position', \
                        type=int, required=True, help='Define the position you want to insert steg mess')
    args = parser.parse_args()
    position = args.position

    payload = gener_payload(position)
    print(payload)
    
