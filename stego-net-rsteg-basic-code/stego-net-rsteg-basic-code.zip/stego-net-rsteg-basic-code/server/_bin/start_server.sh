#!/bin/bash

read -p "Enter source (IP of server): " src
read -p "Enter destination (IP of client): " dst
read -p "Enter position you want server to extract steg mess from: " posi 
sudo python3 /server/server.py -s "$src" -d "$dst" -p "$posi"
