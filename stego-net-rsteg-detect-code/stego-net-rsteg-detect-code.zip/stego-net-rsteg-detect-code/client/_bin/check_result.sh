#!/bin/bash

read -p "Enter Type: " type
read -p "Enter Task: " task
read -p "Enter Value: " value

sudo python3 /client/check_task.py -t "$type" -T "$task" -v "$value"
