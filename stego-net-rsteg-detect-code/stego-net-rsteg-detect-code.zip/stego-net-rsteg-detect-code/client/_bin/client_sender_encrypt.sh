#!/bin/bash

read -p "Enter source IP(IP of client): " src
read -p "Enter destination IP(IP of server): " dst

sudo python3 /client/client_sender_encrypt.py -s "$src" -d "$dst"
