from scapy.all import *
import threading
import time
import random
import argparse
import hashlib
import secrets

SERVER_IP = "0.0.0.0"
CLIENT_IP = "0.0.0.0"

WAITING_TIME = 0
NUMB_OF_RETRAN_PACKETS = 1
NUMB_OF_RSTEG_PACKETS = 1
CURRENT_PACKET_SEQ = 1

RETRANS_PACKET_LIST = []
RSTEG_PACKET_LIST = []
LIST_LOCK = threading.Lock()
PATH = "/client/"
rsteg_signal_file = open(PATH+"encrypt_rsteg_signal",'w')
steg_mess_file = open(PATH + "encrypt_steg_mess", 'w')
steg_mess_file.close()

def start_client():
    global NUMB_OF_RETRAN_PACKETS, NUMB_OF_RSTEG_PACKETS
    global RETRANS_PACKET_LIST, RSTEG_PACKET_LIST
    global LIST_LOCK

    resend_thread_instance = threading.Thread(target=resend_thread)
    resend_thread_instance.daemon = True
    resend_thread_instance.start()

    for num_of_packet in range(1, 2001):
        print(f"Goi tin thu: {num_of_packet}")
        # Công thức tinhs toán tỉ lệ ứng với số lượng gói tin cần truyền
        # Công thức = x = 10(y - 1)/z
        # X: Tỉ lệ cần tính
        # Y: Số lượng gói tin RSTEG/RETRAN tối đa nằm trong tổng Z gói tin đã tin
        # Z: Tổng số lượng gói tin bạn muốn gửi
        # Giả dụ bạn muốn gửi 1000 gói tin, trong đó có 50 gói RSTEG -> Y = 50 và Z = 1000
        appear_rsteg_ratio = (100 - 100 * (NUMB_OF_RSTEG_PACKETS /
                                            (1 + (num_of_packet // 10) * 0.09))) / 100
        appear_rsteg_ratio = max(0, min(1, appear_rsteg_ratio))

        appear_retran_ratio = (100 - 100 * (NUMB_OF_RETRAN_PACKETS /
                                               (1 + (num_of_packet // 10) * 0.69))) / 100
        appear_retran_ratio = max(0, min(1, appear_retran_ratio))

        signal_rsteg_packet = random.choices([True, False], weights=[appear_rsteg_ratio, 1 - appear_rsteg_ratio])
        signal_retran_packet = random.choices([True, False], weights=[appear_retran_ratio, 1 - appear_retran_ratio])

        if signal_retran_packet[0]:
            NUMB_OF_RETRAN_PACKETS += 1
            send_packet(False, True)
            RETRANS_PACKET_LIST.append((CURRENT_PACKET_SEQ, time.time()))

        elif signal_rsteg_packet[0]:
            NUMB_OF_RSTEG_PACKETS += 1
            send_packet(True, False)
            RSTEG_PACKET_LIST.append((CURRENT_PACKET_SEQ, time.time()))
            rsteg_signal_file.write(str(CURRENT_PACKET_SEQ))
            rsteg_signal_file.write("\n")
        else:
            send_packet(False, False)

        time.sleep(0.01) if num_of_packet <= 1000 else time.sleep(0.1)
    rsteg_signal_file.close()


def send_packet(signal_rsteg: bool, retranmis: bool):
    global WAITING_TIME
    global CURRENT_PACKET_SEQ # added global variable usage.

    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
    client_tcp = TCP(sport=random.randint(1024, 65535), dport=8080)

    chr1 = chr(random.randint(33, 126))
    chr2 = chr(random.randint(33, 126))
    chr3 = chr(random.randint(33, 126))
    chr4 = chr(random.randint(33, 126))
    data = generate_random_string()
     # encode the string to bytes.

    # ban đầu sẽ tính toán chksum với payload = None, khi bên kia nhận lại cũng sẽ
    # gom các IP source các thứ và tính toàn lại với chksum = None để khớp
    # Nếu mà tính toàn chksum lúc gán payload rồi thì nó sẽ có rất nhiều cases nên phức tạp hơn
    client_packet = client_ip / client_tcp / Raw()
    CURRENT_PACKET_SEQ = CURRENT_PACKET_SEQ + len(client_packet.load) + 1
    client_packet.seq = CURRENT_PACKET_SEQ
    client_packet_tcp_chksum = client_packet[TCP].build().hex()[32:36]

    if signal_rsteg:
        IS = calcu_IS(CURRENT_PACKET_SEQ, client_packet_tcp_chksum, 0)
        client_packet.load = IS

    elif retranmis:
        IS = calcu_IS(CURRENT_PACKET_SEQ, client_packet_tcp_chksum, 2)
        client_packet.load = IS
        client_packet.load += b"."

    else:
        client_packet.load = data

    send(client_packet, verbose = 0)
    WAITING_TIME = time.time() 

def resend_thread():
    global RETRANS_PACKET_LIST, RSTEG_PACKET_LIST
    
    while True:
        time.sleep(1)
        with LIST_LOCK:
            now = time.time()
            retrans_to_resend = [p for p in RETRANS_PACKET_LIST if now - p[1] >= 5]
            rsteg_to_resend = [p for p in RSTEG_PACKET_LIST if now - p[1] >= 5]

            for seq, timestamp in retrans_to_resend:
                resend_packet(seq, False)
                RETRANS_PACKET_LIST.remove((seq,timestamp))
            for seq, timestamp in rsteg_to_resend:
                resend_packet(seq, True)
                RSTEG_PACKET_LIST.remove((seq,timestamp))

def resend_packet(seq, steg_mess: bool):
    global WAITING_TIME

    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
    client_tcp = TCP()
    data = list(generate_random_string())

    client_packet = client_ip / client_tcp / Raw(load=None)
    client_packet.seq = seq

    if steg_mess:
        steg_mess_file = open(PATH + "encrypt_steg_mess", 'a+')
        # tcp_bytes = client_packet[TCP].build().hex()
        # client_packet_tcp_chksunm = tcp_bytes[32:36]
        # print("Day la chuoi bytes cua tcp header trc khi gui: {tcp}".format(tcp=tcp_bytes))
        # IS = calcu_IS(client_packet.seq, client_packet_tcp_chksunm, 1)
        # client_packet.load = IS
        data[30] = 'P'
        client_packet.load = "".join(data).encode()
        send(client_packet, verbose=0)
        print(f"Resend packet with seq={seq}".format(seq=seq))
        WAITING_TIME = time.time()

        data = list(generate_random_string())
        seq = seq + len(data) + 1
        data[30] = 'T'
        client_packet.load = "".join(data).encode()
        client_packet[TCP].seq = seq
        # THeem seq của gói tin vào file steg_mess
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        send(client_packet, verbose=0)
        # print(f"Resend steg_package with seq={seq}")
        WAITING_TIME = time.time

        data = list(generate_random_string())
        seq = seq + len(data) + 1
        data[30] = 'I'
        client_packet.load = "".join(data).encode()
        client_packet[TCP].seq = seq
        # THeem seq của gói tin vào file steg_mess
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        send(client_packet, verbose=0)
        # print("Resend steg_package with seq={seq}".format(seq=seq))
        WAITING_TIME = time.time

        data = list(generate_random_string())
        seq = seq + len(data) + 1
        data[30] = 'T'
        client_packet.load = "".join(data).encode()
        client_packet[TCP].seq = seq
        # THeem seq của gói tin vào file steg_mess
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        send(client_packet, verbose=0)
        # print("Resend steg_package with seq={seq}".format(seq=seq))
        WAITING_TIME = time.time
        
    else:
        client_packet.load = "".join(data).encode()
        
        print("Resend packet with seq={seq}".format(seq=seq))
        
    send(client_packet, verbose=0)
    WAITING_TIME = time.time()


def calcu_IS(seq: str, chksum: str, sign_bit):
    unhashed_str = str(seq) + chksum + str(sign_bit)
    unhashed_str = unhashed_str.encode('utf-8')
    # print("Unhash_Str:", unhashed_str)
    hashed_str = hashlib.sha256(unhashed_str)
    hashed_hex = hashed_str.hexdigest()

    # print("SHA-256 hash:", hashed_hex)
    return hashed_hex

def generate_random_string(length=64):
    """Tạo chuỗi ngẫu nhiên 32 ký tự."""
    alphabet = string.ascii_letters + string.digits  # Chữ cái và chữ số
    random_string = ''.join(secrets.choice(alphabet) for i in range(length))
    return random_string

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-s', '--src', dest='source', required=True, help='source IP (client)') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='destination IP (server)') # corrected help message

    args = parser.parse_args()
    CLIENT_IP = args.source
    SERVER_IP = args.destination

    print("Start to send packet to Server From Client...")
    start_client()
