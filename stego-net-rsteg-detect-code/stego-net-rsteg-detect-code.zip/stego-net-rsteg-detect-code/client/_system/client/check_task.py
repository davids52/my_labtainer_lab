import argparse
status  = False
PATH = "/client/"
# PATH = "C:\\Users\\Admin\\Downloads\\"

def check_task1(type:str, value:str):
    global PATH, status
    if(type == 'rsteg_signal_seq_check'):
        try:
            seq_file = open(PATH + "normal_rsteg_signal", 'r')
            for line in seq_file:
            # print(line)
                seq = line.strip()

                if(value == seq):
                    status = True
                    break

            if(status):
                print("Task1 solved, you've found correct rsteg_signal packet!!!")
                
            else:
                print("Incorrect rsteg_signal packet, Please try again!!!")
            seq_file.close()

        except FileNotFoundError:
            print("You must run client_sender.sh first")
        

    elif(type == 'steg_mess_seq_check'):
        try:
            seq_file = open(PATH + "normal_steg_mess", 'r')
            for line in seq_file.readlines():
                seq = line.strip()
                
                if(value == seq):
                    status = True
                    break
            if(status):
                print("Task1 solved, you've found correct steg_mess packet!!!")
            
            else:
                print("Incorrect steg_mess packet, Please try again!!!")
            seq_file.close()

        except FileNotFoundError:
            print("You must run client_sender.sh first")
        
    
    elif(type == 'steg_mess_check'):
        if(value == 'PTiT'):
            print("Task1 solved, Well my message seems leaked...Congratulation!!!")
        
        else:
            print("My message is not like this, Please try again!!!")

def check_task2(type:str, value:str):
    global PATH, status
    status = False  # Reset trạng thái mỗi lần check
    
    if(type == 'rsteg_signal_seq_check'):
        try:
            seq_file = open(PATH + "encrypt_rsteg_signal", 'r')
            for line in seq_file:
                seq = line.strip()
                if(value == seq):
                    status = True
                    break
            
            if(status):
                print("Task2 solved, you've found correct rsteg_signal packet!!!")
            else:
                print("Incorrect rsteg_signal packet, Please try again!!!")
            
            seq_file.close()
        except FileNotFoundError:
            print("You must run client_sender_encrypt.sh first")

    elif(type == 'steg_mess_seq_check'):
        try:
            seq_file = open(PATH + "encrypt_steg_mess", 'r')
            for line in seq_file:
                seq = line.strip()
                if(value == seq):
                    status = True
                    break
            
            if(status):
                print("Task2 solved, you've found correct steg_mess packet!!!")
            else:
                print("Incorrect steg_mess packet, Please try again!!!")
            
            seq_file.close()
        except FileNotFoundError:
            print("You must run client_sender_encrypt.sh first")
    
    elif(type == 'steg_mess_check'):
        if(value == 'PTIT'):
            print("Task2 solved. Well my message seems leaked...Congratulation!!!")
        else:
            print("My message is not like this, Please try again!!!")

if __name__ == '__main__':
    parser = argparse.ArgumentParser('Check correct sequence')
    parser.add_argument('-t', '--type', dest='type', required=True, help='Define type to check')
    parser.add_argument('-T', '--task', dest='task', required=True, help='Define the task that you want to check')
    parser.add_argument('-v', '--value', dest='value', required=True, help='Define need checked value to solve the task')
    args = parser.parse_args()

    if(args.task == "1"):
        check_task1(args.type, args.value)
    
    elif(args.task == "2"):
        check_task2(args.type, args.value)
    
    else:
        print("Task's value can assigned only 1 or 2.")
