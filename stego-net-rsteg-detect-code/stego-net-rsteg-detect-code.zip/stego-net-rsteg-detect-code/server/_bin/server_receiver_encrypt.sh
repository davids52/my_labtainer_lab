#!/bin/bash

read -p "Enter source IP(IP of server): " src
read -p "Enter destination IP(IP of client): " dst

sudo python3 /server/server_receiver_encrypt.py -s "$src" -d "$dst"
