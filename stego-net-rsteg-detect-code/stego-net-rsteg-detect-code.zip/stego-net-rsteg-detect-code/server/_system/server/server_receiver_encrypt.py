from scapy.all import *
import time
import random
import argparse
import hashlib

SERVER_IP = "0.0.0.0"
CLIENT_IP = "0.0.0.0"

WAITING_TIME = 0
CURRENT_PACKET_SEQ = 1
TOTAL = 00

def packet_handler(packet):   
    global WAITING_TIME, TOTAL

    if(time.time() - WAITING_TIME < 0.01):
        return

    if (packet[IP].src == CLIENT_IP):
        TOTAL += 1
        tcp_bytes = packet[TCP].build().hex()
        
        client_pakage_tcp_chksum = calculate_old_tcp_chksum(tcp_bytes, SERVER_IP, CLIENT_IP)
        # print("Day la chksum tinh toan lai ne: seq: {seq}----> {old_chksum}".format(seq=packet.seq, old_chksum=client_pakage_tcp_chksum))
        signal_rsteg = calcu_IS(packet[TCP].seq, client_pakage_tcp_chksum, 0)
        retranmis = calcu_IS(packet[TCP].seq, client_pakage_tcp_chksum, 2)

        if(packet.load.decode() == str(signal_rsteg)):
            pass
            # print(f"Found packet with signal_rsteg, packet: {packet[TCP].seq}")

        elif(packet.load.decode() == str(retranmis)):
            pass
            # print(f"Found retranmission, packet: {packet[TCP].seq}")

        else:
            send_packet(packet)

    # print(f"Da xu li tong cong {TOTAL} goi tin")

def send_packet(client_packet):
    global CURRENT_PACKET_SEQ
    global WAITING_TIME

    server_ip = IP(src = SERVER_IP, dst = CLIENT_IP)
    server_tcp = TCP(seq = CURRENT_PACKET_SEQ, ack = client_packet.seq + len(client_packet.load), flags='A')
    CURRENT_PACKET_SEQ += 1

    server_packet = server_ip / server_tcp
    send(server_packet, verbose= 0)
    WAITING_TIME = time.time()

def calcu_IS(seq: str, chksum: str, sign_bit: str): 
    unhashed_str = str(seq) + chksum + str(sign_bit)
    unhashed_str = unhashed_str.encode('utf-8')
    # print("Unhashed_string: ", unhashed_str)
    hashed_str = hashlib.sha256(unhashed_str)
    hashed_hex = hashed_str.hexdigest()

    # print("SHA-256 hash:", hashed_hex)
    return hashed_hex

def calculate_old_tcp_chksum(tcp_bytes, ip_src, ip_dst):
    # Tách TCP header và payload
    tcp = bytes.fromhex(tcp_bytes)
    tcp_header = tcp[:20]
    payload = None

    # Trích xuất các trường TCP
    sport = int.from_bytes(tcp_header[0:2], 'big')
    dport = int.from_bytes(tcp_header[2:4], 'big')
    seq = int.from_bytes(tcp_header[4:8], 'big')
    ack = int.from_bytes(tcp_header[8:12], 'big')
    data_offset_reserved_flags = int.from_bytes(tcp_header[12:14], 'big')
    window = int.from_bytes(tcp_header[14:16], 'big')
    checksum_received = int.from_bytes(tcp_header[16:18], 'big')
    urg_ptr = int.from_bytes(tcp_header[18:20], 'big')

    data_offset = (data_offset_reserved_flags >> 12)
    flags = (data_offset_reserved_flags & 0x3f)

    ip = IP(src=ip_src, dst=ip_dst, proto=6) 
    tcp = TCP(
        sport=sport,
        dport=dport,
        seq=seq,
        ack=ack,
        dataofs=data_offset,
        flags=flags,
        window=window,
        urgptr=urg_ptr,
        chksum=None  # Đặt checksum = 0 để Scapy tính lại
    )

    packet = ip / tcp / Raw(load=None)
    # print("Tinh toan lai packet cua seq: {seq} ---> {hehe}".format(seq=packet.seq, hehe=packet[TCP].build().hex()))
    old_tcp_checksum = packet[TCP].build().hex()[32:36]
    return old_tcp_checksum

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-s', '--src', dest='source', required=True, help='source IP (server)') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='destination IP (client)') # corrected help message

    args = parser.parse_args()
    CLIENT_IP = args.destination
    SERVER_IP = args.source

    print("Ready to receive packet From Client...")
    sniff(filter=f"ip and src host {CLIENT_IP} and not tcp-ack", prn=packet_handler, store=0)
