from scapy.all import *
import threading
import time
import random
import argparse

SERVER_IP = "0.0.0.0"
CLIENT_IP = "0.0.0.0"

WAITING_TIME = 0
NUMB_OF_RETRAN_PACKAGES = 1
NUMB_OF_RSTEG_PACKAGES = 1
CURRENT_PACKAGE_SEQ = 1

RETRANS_PACKAGE_LIST = []
RSTEG_PACKAGE_LIST = []
LIST_LOCK = threading.Lock()

PATH = "/home/kali/Downloads/stego-network-rseg-attack-code/"
rsteg_signal_file = open(PATH+"normal_rsteg_signal",'w')
steg_mess_file = open(PATH + "normal_steg_mess", 'w')
steg_mess_file.close()

def start_client():
    global NUMB_OF_RETRAN_PACKAGES, NUMB_OF_RSTEG_PACKAGES
    global RETRANS_PACKAGE_LIST, RSTEG_PACKAGE_LIST
    global LIST_LOCK

    resend_thread_instance = threading.Thread(target=resend_thread)
    resend_thread_instance.daemon = True
    resend_thread_instance.start()

    for num_of_package in range(1, 2001):
        print("Goi tin thu: {num_of_package}".format(num_of_package=num_of_package))
        # Công thức tinhs toán tỉ lệ ứng với số lượng gói tin cần truyền
        # Công thức = x = 10(y - 1)/z
        # X: Tỉ lệ cần tính
        # Y: Số lượng gói tin RSTEG/RETRAN tối đa nằm trong tổng Z gói tin đã tin
        # Z: Tổng số lượng gói tin bạn muốn gửi
        # Giả dụ bạn muốn gửi 1000 gói tin, trong đó có 50 gói RSTEG -> Y = 50 và Z = 1000
        appear_rsteg_ratio = (100 - 100 * (NUMB_OF_RSTEG_PACKAGES /
                                            (1 + (num_of_package // 10) * 0.09))) / 100
        appear_rsteg_ratio = max(0, min(1, appear_rsteg_ratio))

        appear_retran_ratio = (100 - 100 * (NUMB_OF_RETRAN_PACKAGES /
                                               (1 + (num_of_package // 10) * 0.69))) / 100
        appear_retran_ratio = max(0, min(1, appear_retran_ratio))

        signal_rsteg_package = random.choices([True, False], weights=[appear_rsteg_ratio, 1 - appear_rsteg_ratio])
        signal_retran_package = random.choices([True, False], weights=[appear_retran_ratio, 1 - appear_retran_ratio])

        if signal_retran_package[0]:
            NUMB_OF_RETRAN_PACKAGES += 1
            send_package(False, True)
            RETRANS_PACKAGE_LIST.append((CURRENT_PACKAGE_SEQ, time.time()))

        elif signal_rsteg_package[0]:
            NUMB_OF_RSTEG_PACKAGES += 1
            send_package(True, False)
            RSTEG_PACKAGE_LIST.append((CURRENT_PACKAGE_SEQ, time.time()))
            rsteg_signal_file.write(str(CURRENT_PACKAGE_SEQ))
            rsteg_signal_file.write("\n")
        else:
            send_package(False, False)

        time.sleep(0) if num_of_package <= 1000 else time.sleep(0.1)
    rsteg_signal_file.close()

def rsteg_thread():
    global NUMB_OF_RETRAN_PACKAGES
    global NUMB_OF_RSTEG_PACKAGES
    global WAITING_TIME

    NUMB_OF_RSTEG_PACKAGES += 1
    NUMB_OF_RETRAN_PACKAGES += 1

    #send RSTEG package
    send_package(True, False, False)    
    RSTEG_PAKAGE_LIST.append((CURRENT_PACKAGE_SEQ, time.time()))
    time.sleep(3)

def send_package(signal_rsteg: bool, retranmis: bool):
    global WAITING_TIME
    global CURRENT_PACKAGE_SEQ # added global variable usage.

    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
    client_tcp = TCP(sport=random.randint(1024, 65535), dport=8080)

    chr1 = chr(random.randint(33, 126))
    chr2 = chr(random.randint(33, 126))
    chr3 = chr(random.randint(33, 126))
    chr4 = chr(random.randint(33, 126))
    data = "{chr1}\x00\x00\x00{chr2}\x00\x00\x00{chr3}\x00\x00{chr4}\x00\x00\x00".format(chr1=chr1, chr2=chr2, chr3=chr3, chr4=chr4)
    payload = Raw(load=data.encode()) # encode the string to bytes.

    client_package = client_ip / client_tcp / payload
    CURRENT_PACKAGE_SEQ = CURRENT_PACKAGE_SEQ + len(client_package.load) + 1
    client_package.seq = CURRENT_PACKAGE_SEQ

    if signal_rsteg:
        client_package[IP].flags = 2
        
    elif retranmis:
        client_package[IP].flags = 2
        client_package.load = client_package.load[:-1] + b'S' # Corrected retransmission payload modification

    send(client_package, verbose = 0)
    WAITING_TIME = time.time() 

# def send_package(signal_rsteg: bool, retranmis: bool):
#     global WAITING_TIME
#     global CURRENT_PACKAGE_SEQ

#     # Sinh port ngẫu nhiên cho client
#     client_sport = random.randint(1024, 65535)
#     client_dport = 8080  # Port server

#     client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
#     client_tcp = TCP(sport=client_sport, dport=client_dport, seq=CURRENT_PACKAGE_SEQ)  # Set port và sequence number

#     # Tạo payload
#     chr1 = chr(random.randint(33, 126))
#     data = f"{chr1}\x00\x00\x00..."
#     payload = Raw(load=data.encode())

#     client_package = client_ip / client_tcp / payload
#     CURRENT_PACKAGE_SEQ += len(client_package)

#     if signal_rsteg or retranmis:
#         client_package[IP].flags = 2  # Ví dụ: Sử dụng cờ IP

#     send(client_package, verbose=0)
#     WAITING_TIME = time.time()

def resend_thread():
    global RETRANS_PACKAGE_LIST, RSTEG_PACKAGE_LIST
    
    while True:
        time.sleep(1)
        with LIST_LOCK:
            now = time.time()
            retrans_to_resend = [p for p in RETRANS_PACKAGE_LIST if now - p[1] >= 5]
            rsteg_to_resend = [p for p in RSTEG_PACKAGE_LIST if now - p[1] >= 5]

            for seq, timestamp in retrans_to_resend:
                resend_package(seq, False)
                RETRANS_PACKAGE_LIST.remove((seq,timestamp))
            for seq, timestamp in rsteg_to_resend:
                resend_package(seq, True)
                RSTEG_PACKAGE_LIST.remove((seq,timestamp))

def resend_package(seq, steg_mess: bool):
    
    global WAITING_TIME

    client_ip = IP(src=CLIENT_IP, dst=SERVER_IP)
    client_tcp = TCP()

    chr1 = chr(random.randint(33, 126))
    chr2 = chr(random.randint(33, 126))
    chr3 = chr(random.randint(33, 126))
    chr4 = chr(random.randint(33, 126))
    data = "{chr1}\x00\x00\x00{chr2}\x00\x00\x00{chr3}\x00\x00{chr4}\x00\x00\x00".format(chr1=chr1, chr2=chr2, chr3=chr3, chr4=chr4)
    payload = Raw(load=data.encode())

    client_package = client_ip / client_tcp / payload
    client_package.seq = seq

    if steg_mess:
        steg_mess_file = open(PATH + 'normal_steg_mess','a+')

        client_package[IP].id = seq
        client_package[IP].flags = 4
        client_package.load = b"\x00\x00\x00\x00\x00\x00\x00\x00P\x00\x00\x00\x00\x00\x00\x00"
        send(client_package, verbose=0)
        WAITING_TIME = time.time()
        # print(f"Resend package with seq={seq}")

        seq = seq + len(client_package.load) + 1
        client_package[TCP].seq = seq
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        client_package.load = b"\x00\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00\x00\x00\x00\x00"
        send(client_package, verbose=0)
        WAITING_TIME = time.time()
        # print(f"Resend package with seq={seq}")

        seq = seq + len(client_package.load) + 1
        client_package[TCP].seq = seq
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        client_package.load = b"\x00\x00\x00\x00\x00\x00\x00\x00i\x00\x00\x00\x00\x00\x00\x00" 
        send(client_package, verbose=0)
        WAITING_TIME = time.time()
        # print(f"Resend package with seq={seq}")

        seq = seq + len(client_package.load) + 1
        client_package[IP].flags = 0
        client_package[TCP].seq = seq
        steg_mess_file.write(str(seq))
        steg_mess_file.write("\n")
        client_package.load = b"\x00\x00\x00\x00\x00\x00\x00T\x00\x00\x00\x00\x00\x00\x00"
        send(client_package, verbose=0)
        WAITING_TIME = time.time()
        # print(f"Resend package with seq={seq}")
        steg_mess_file.close()

    else:
        send(client_package, verbose=0)
        WAITING_TIME = time.time()
        # print(f"Resend package with seq={seq}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-s', '--src', dest='source', required=True, help='source IP (client)') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='destination IP (server)') # corrected help message

    args = parser.parse_args()
    CLIENT_IP = args.source
    SERVER_IP = args.destination

    print("Start to send packet to Server From Client...")
    start_client()
