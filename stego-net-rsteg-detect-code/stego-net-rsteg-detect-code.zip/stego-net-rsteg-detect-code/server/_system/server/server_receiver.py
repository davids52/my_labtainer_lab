from scapy.all import *
import time
import random
import argparse

SERVER_IP = "0.0.0.0"
CLIENT_IP = "0.0.0.0"

WAITING_TIME = 0
CURRENT_PACKAGE_SEQ = 1
TOTAL = 00

def package_handler(package):   
    global WAITING_TIME, TOTAL

    if(time.time() - WAITING_TIME < 2 ):
        return

    if (package[IP].src == CLIENT_IP):
        TOTAL += 1

        if(package[IP].flags == 2):
            pass
        else:
            send_package(package)
    print(f"Da xu li tong cong {TOTAL} goi tin")

def send_package(client_package):
    global CURRENT_PACKAGE_SEQ

    server_ip = IP(src = SERVER_IP, dst = CLIENT_IP)
    server_tcp = TCP(seq = CURRENT_PACKAGE_SEQ, ack = client_package.seq + len(client_package.load), flags='A')
    CURRENT_PACKAGE_SEQ += 1

    server_package = server_ip / server_tcp
    send(server_package, verbose= 0)
    WAITING_TIME = time.time()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Client Sender")
    parser.add_argument('-s', '--src', dest='source', required=True, help='source IP (server)') # corrected help message
    parser.add_argument('-d', '--dst', dest='destination', required=True, help='destination IP (client)') # corrected help message

    args = parser.parse_args()
    CLIENT_IP = args.destination
    SERVER_IP = args.source

    print("Ready to receive package From Client...")
    sniff(filter=f"ip and src host {CLIENT_IP} and not tcp-ack", prn=package_handler, store=0)
